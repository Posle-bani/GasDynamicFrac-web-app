import os

__version__ = os.getenv("APP_VERSION", "dev")
